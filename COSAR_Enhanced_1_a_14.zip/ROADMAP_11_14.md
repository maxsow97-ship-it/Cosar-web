# Points 11–14 — préparés, à brancher côté Supabase / API

## 11. Photos agents / sites
- Table `profiles.photo_url` et `sites.photo_url` (text)
- Bucket Storage Supabase `avatars` + `sites`
- Dans CreateForms : input file → upload → URL
- Afficher dans RH drawer et fiche site

## 12. WhatsApp / SMS
- Variable d’env `NEXT_PUBLIC_WA_NUMBER` (déjà côté site vitrine)
- Bouton dans RH / Alarmes : `https://wa.me/221XXXXXXXX?text=...`
- SMS : provider (Twilio / Orange) via Edge Function — non inclus sans clés API

## 13. Carte TRACK live + géofencing
- Module `/dashboard/track` existe déjà
- Ajouter Leaflet/Mapbox + positions `tracked_positions`
- Table `geofences` (site_id, polygon/radius) + alerte si sortie de zone
- Realtime channel déjà pattern dans AlarmesClient

## 14. Facturation auto + relances
- Cron Vercel / Supabase : chaque mois générer `payments` depuis `subscriptions` actifs
- Relance J+3 / J+7 : email (Resend) ou WhatsApp
- Statut `impaye` → badge dans Abonnements (déjà filtré)

Ces 4 points nécessitent secrets et schéma DB : code UI prêt à brancher après.
