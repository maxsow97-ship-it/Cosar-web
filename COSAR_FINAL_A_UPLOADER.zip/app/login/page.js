'use client';
import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const params = useSearchParams();
  const accessDenied = params.get('error') === 'acces_refuse';

  async function handleLogin(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const supabase = createClient();
    const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });
    if (authError) {
      setLoading(false);
      setError('Email ou mot de passe incorrect.');
      return;
    }

    const userId = data?.user?.id;
    let dest = '/dashboard';
    if (userId) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', userId)
        .single();
      const role = profile?.role;
      if (role === 'client') dest = '/client';
      else if (role === 'agent') dest = '/dashboard/mon-espace';
      else dest = '/dashboard';
    }

    setLoading(false);
    router.push(dest);
    router.refresh();
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{ background: 'linear-gradient(160deg, #182038 0%, #10182C 55%, #0c1220 100%)' }}
    >
      <div className="w-full max-w-sm bg-white rounded-2xl border border-[#E7E9EE] shadow-2xl p-8">
        <div className="text-center mb-7">
          <div className="inline-flex items-center justify-center bg-[#F6F7FA] rounded-xl p-3 mb-4 border border-[#E7E9EE]">
            <img src="/cosar-shield.png" alt="COSAR" className="w-14 h-14 object-contain" />
          </div>
          <div className="text-2xl tracking-wide" style={{ fontFamily: 'Oswald, sans-serif', fontWeight: 600 }}>
            <span className="text-[#182038]">COSAR</span>{' '}
            <span className="text-[#D9A600]">ONE</span>
          </div>
          <p className="text-[#D9A600] text-[11px] uppercase tracking-[0.14em] mt-1" style={{ fontFamily: 'Oswald, sans-serif' }}>
            L&apos;œil qui veille
          </p>
          <p className="text-[#5B6472] text-sm mt-2">Back office — Administration</p>
        </div>

        {accessDenied && (
          <div className="mb-4 text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2">
            Ce compte n&apos;a pas accès au back office.
          </div>
        )}
        {error && (
          <div className="mb-4 text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#5B6472] mb-1">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-[#E7E9EE] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#F8C018] bg-[#F6F7FA]"
              placeholder="vous@cosar-group.online"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#5B6472] mb-1">Mot de passe</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-[#E7E9EE] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#F8C018] bg-[#F6F7FA]"
              placeholder="••••••••"
            />
          </div>
          <button type="submit" disabled={loading} className="btn-gold w-full disabled:opacity-60">
            {loading ? 'Connexion…' : 'Se connecter'}
          </button>
        </form>
        <p className="text-center text-[11px] text-[#5B6472] mt-6">
          Exigence. Présence. Confiance.
        </p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}
