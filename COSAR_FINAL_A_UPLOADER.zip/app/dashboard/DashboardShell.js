'use client';
import { useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

/** Logo officiel du site — ne plus utiliser de base64 qui change */
const LOGO = '/cosar-shield.png';
const LOGO_NAV = '/cosar-shield-nav.png';

const ALL_NAV = [
  { href: '/dashboard', icon: '📃', label: 'Devis & Leads', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/operations', icon: '📡', label: 'Centre Opérationnel', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/rh', icon: '👤', label: 'RH & Agents', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/alarmes', icon: '🚨', label: 'Alarmes & IoT', roles: ['admin', 'superviseur'], badge: 'alarms' },
  { href: '/dashboard/abonnements', icon: '💳', label: 'Abonnements', roles: ['admin'] },
  { href: '/dashboard/track', icon: '📍', label: 'COSAR TRACK', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/sites', icon: '🛡️', label: 'Sites & Rondes', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/catalogue', icon: '🧾', label: 'Catalogue & Factures', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/k9', icon: '🐾', label: 'Registre K9', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/stock', icon: '📦', label: 'Stock & Matériel', roles: ['admin', 'superviseur'] },
  { href: '/dashboard/mon-espace', icon: '🪪', label: 'Mon espace', roles: ['agent'] },
  { href: '/dashboard/utilisateurs', icon: '👥', label: 'Utilisateurs & Accès', roles: ['admin'] },
  { href: '/dashboard/activite', icon: '📜', label: "Journal d'activité", roles: ['admin'] },
  { href: '/dashboard/parametres', icon: '⚙️', label: 'Paramètres', roles: ['admin', 'superviseur', 'agent'] },
];

export default function DashboardShell({ userName, role = 'admin', badges = {}, children }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState('');
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();

  const nav = ALL_NAV.filter((item) => !item.roles || item.roles.includes(role));

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/login');
  }

  function runSearch(e) {
    e.preventDefault();
    const term = q.trim();
    if (!term) return;
    if (role === 'agent') router.push('/dashboard/mon-espace');
    else if (/alarme|iot/i.test(term)) router.push('/dashboard/alarmes');
    else if (/agent|rh|contrat|congé/i.test(term)) router.push('/dashboard/rh');
    else if (/abonnement|paiement|facture/i.test(term)) router.push('/dashboard/abonnements');
    else if (/site|ronde/i.test(term)) router.push('/dashboard/sites');
    else if (/track|gps|flotte/i.test(term)) router.push('/dashboard/track');
    else router.push('/dashboard');
    setSearchOpen(false);
    setQ('');
  }

  const sidebar = (
    <div className="flex flex-col h-full shell-sidebar">
      <div className="flex items-center gap-3 px-5 py-6 border-b border-white/10">
        <div className="bg-white rounded-lg p-1.5 shadow-sm shrink-0">
          <img src={LOGO} alt="COSAR" className="w-9 h-9 object-contain" />
        </div>
        <div>
          <div className="text-white text-sm leading-tight" style={{ fontFamily: 'Oswald, sans-serif', fontWeight: 600 }}>
            COSAR <span className="text-[#F8C018]">ONE</span>
          </div>
          <div className="text-[#F8C018]/70 text-[10px] uppercase tracking-wider" style={{ fontFamily: 'Oswald, sans-serif' }}>
            L&apos;œil qui veille
          </div>
        </div>
      </div>
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {nav.map((item) => {
          const active = pathname === item.href || (item.href !== '/dashboard' && pathname?.startsWith(item.href));
          const count = item.badge ? (badges[item.badge] || 0) : 0;
          return (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${active ? 'shell-nav-active' : 'shell-nav-idle'}`}
            >
              <span className="text-base w-5 text-center">{item.icon}</span>
              <span className="flex-1">{item.label}</span>
              {count > 0 && (
                <span className={`text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center ${active ? 'bg-[#182038] text-[#F8C018]' : 'bg-red-500 text-white'}`}>
                  {count > 99 ? '99+' : count}
                </span>
              )}
            </a>
          );
        })}
      </nav>
      <div className="px-3 pb-5 pt-3 border-t border-white/10">
        {userName && <div className="px-3 pb-0.5 text-xs text-white/60 truncate">{userName}</div>}
        {role && (
          <div className="px-3 pb-2 text-[10px] uppercase tracking-widest text-[#F8C018]/80" style={{ fontFamily: 'Oswald, sans-serif' }}>
            {role}
          </div>
        )}
        <button
          type="button"
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/80 hover:bg-white/10 hover:text-white transition-colors"
        >
          <span className="text-base w-5 text-center">🚪</span>
          <span>Déconnexion</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F6F7FA]">
      <aside className="hidden md:flex fixed inset-y-0 left-0 w-60 flex-col z-30 shadow-xl">
        {sidebar}
      </aside>

      <div className="md:hidden sticky top-0 z-30 shell-sidebar flex items-center justify-between px-4 py-3">
        <button type="button" onClick={() => setMobileOpen(true)} className="text-white text-2xl leading-none" aria-label="Menu">☰</button>
        <div className="flex items-center gap-2">
          <div className="bg-white rounded-md p-1 shadow-sm">
            <img src={LOGO_NAV} alt="COSAR" className="w-6 h-6 object-contain" />
          </div>
          <span className="text-white text-sm" style={{ fontFamily: 'Oswald, sans-serif', fontWeight: 600 }}>
            COSAR <span className="text-[#F8C018]">ONE</span>
          </span>
        </div>
        <button type="button" onClick={() => setSearchOpen((v) => !v)} className="text-white text-lg" aria-label="Recherche">🔍</button>
      </div>

      <div className="hidden md:flex md:pl-60 sticky top-0 z-20 bg-white/95 backdrop-blur border-b border-[#E7E9EE] px-6 py-2.5 items-center gap-3">
        <form onSubmit={runSearch} className="flex-1 max-w-md">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Recherche (agent, alarme, site, track…)"
            className="w-full border border-[#E7E9EE] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#F8C018] bg-[#F6F7FA]"
          />
        </form>
        {(badges.alarms || 0) > 0 && (
          <a href="/dashboard/alarmes" className="text-xs font-semibold bg-red-50 text-red-700 border border-red-200 rounded-full px-3 py-1">
            {badges.alarms} alarme{badges.alarms > 1 ? 's' : ''}
          </a>
        )}
        {(badges.leaves || 0) > 0 && (
          <a href="/dashboard/rh" className="text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200 rounded-full px-3 py-1">
            {badges.leaves} congé{badges.leaves > 1 ? 's' : ''}
          </a>
        )}
      </div>

      {searchOpen && (
        <div className="md:hidden bg-white border-b border-[#E7E9EE] px-4 py-2">
          <form onSubmit={runSearch}>
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Rechercher…"
              className="w-full border border-[#E7E9EE] rounded-lg px-3 py-2 text-sm"
            />
          </form>
        </div>
      )}

      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="w-64 h-full shadow-xl">{sidebar}</div>
          <div className="flex-1 bg-black/40" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      <div className="md:pl-60">{children}</div>
    </div>
  );
}
