-- COSAR ONE — créer / rattacher un admin (à exécuter dans Supabase → SQL Editor)
-- 1) Crée d'abord l'utilisateur dans Authentication → Users (email + mot de passe)
-- 2) Copie l'UUID de l'utilisateur, remplace ci-dessous, exécute

-- Exemple (remplace UUID et email) :
insert into public.profiles (id, email, nom_complet, role)
values (
  'REMPLACER_PAR_UUID_AUTH',
  'admin@cosar-group.online',
  'Magatte Sow',
  'admin'
)
on conflict (id) do update
set role = 'admin',
    nom_complet = excluded.nom_complet,
    email = excluded.email;

-- Rôles possibles : admin | superviseur | agent | client
