# COSAR ONE — Back Office

Application Next.js (tableau de bord administrateur), à déployer sur Vercel, connectée à ta base Supabase existante.

## ⚠️ Important — non testé en conditions réelles

Cet environnement de développement n'a pas d'accès réseau : je n'ai pas pu exécuter `npm install` ni `npm run build`
pour vérifier que le projet compile sans erreur. Le code suit des schémas standards et éprouvés (Next.js 14 App Router,
@supabase/ssr, recharts), mais **teste-le en local avant de le pousser sur Vercel** — voir étape 2 ci-dessous.
Si tu rencontres une erreur, copie-la et renvoie-la moi, je corrigerai.

## Ce que contient l'application

- **Connexion** (`/login`) — même compte que l'espace client/agent COSAR ONE (Supabase Auth).
- **Tableau de bord** (`/dashboard`, protégé — admin/superviseur uniquement) :
  - KPI : total reçu, devis, candidatures, 7 derniers jours, à traiter.
  - Graphique des visites du site et des demandes reçues (14 derniers jours).
  - Pages les plus visitées.
  - Table de tous les devis et candidatures : recherche, filtre par type/statut, changement de statut en un clic,
    téléchargement direct du CV joint.

## Étapes de déploiement

### 1. Installer les dépendances (en local, sur ton ordinateur)

```bash
npm install
```

### 2. Tester en local

```bash
npm run dev
```
Ouvre http://localhost:3000 — tu dois être redirigé vers `/login`. Connecte-toi avec le compte
`m.sow@cosar-group.online` (même mot de passe que l'espace client/agent). Si une erreur apparaît dans le terminal,
copie-la intégralement.

### 3. Pousser sur GitHub

```bash
git init
git add .
git commit -m "COSAR ONE back office"
git remote add origin <URL_DE_TON_DEPOT_GITHUB>
git push -u origin main
```

### 4. Connecter à Vercel

- Dans Vercel, importe ce dépôt GitHub (ou utilise celui déjà lié à ton projet Supabase).
- Dans **Project Settings → Environment Variables**, ajoute :
  - `NEXT_PUBLIC_SUPABASE_URL` = `https://dbjosvjogszdoitnclly.supabase.co`
  - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = `sb_publishable_Nn0JiWsm0mdRe3aQmF-PYw_qWz7rPSr`
- Déploie. Le fichier `.env.local` local n'est jamais poussé sur GitHub (il est dans `.gitignore`) — c'est normal et voulu.

### 5. Premier accès

Va sur l'URL Vercel générée → tu arrives sur `/login` → connecte-toi avec ton compte admin habituel.

## Sécurité

- Seuls les comptes avec le rôle `admin` ou `superviseur` (table `profiles`) peuvent accéder au tableau de bord —
  vérifié à la fois par le middleware Next.js et par les règles de sécurité (RLS) Supabase.
- Un point de sécurité a été corrigé sur la table `devis` pendant ce travail : elle autorisait auparavant n'importe
  quel compte connecté (pas seulement les admins) à voir tous les devis/candidatures. C'est maintenant restreint
  correctement.
