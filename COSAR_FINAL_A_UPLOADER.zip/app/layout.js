import './globals.css';

export const metadata = {
  title: 'COSAR ONE — L\'œil qui veille',
  description: 'Back office COSAR GROUP — Exigence. Présence. Confiance.',
  robots: 'noindex, nofollow',
  icons: {
    icon: '/cosar-shield-nav.png',
    apple: '/cosar-shield.png',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body className="bg-[#F6F7FA] text-[#14181F] antialiased">{children}</body>
    </html>
  );
}
