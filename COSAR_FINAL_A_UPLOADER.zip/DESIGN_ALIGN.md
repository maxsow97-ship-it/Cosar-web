# Alignement design App ↔ Site

## Règles (Document Maître + site vitrine)

| Token | Valeur |
|-------|--------|
| Navy | `#182038` |
| Navy deep | `#10182C` |
| Or | `#F8C018` |
| Or profond | `#D9A600` |
| Interdit | `#181028` |
| Corps | Work Sans |
| Titres | Oswald |
| Slogan groupe | Exigence. Présence. Confiance. |
| Slogan ONE | L'œil qui veille |

## Logo stable

- `public/cosar-shield.png` — bouclier officiel du site
- `public/cosar-shield-nav.png` — version nav
- **Ne plus** embarquer de base64 dans DashboardShell (cause des changements visuels)

## Fichiers à remplacer / ajouter dans Cosar-web

```
app/globals.css
app/layout.js
app/login/page.js
app/dashboard/DashboardShell.js
public/cosar-shield.png
public/cosar-shield-nav.png
```

(GitHub en suspend — à uploader quand tu reprendras.)
