# COSAR ONE — Package final à uploader

**DNS exclu** (point 3 en pause).

## Contenu

| Chemin | Rôle |
|--------|------|
| `app/globals.css` + `layout.js` | Design = site (Oswald, Work Sans, navy/or) |
| `app/login/page.js` | Login + redirect selon rôle |
| `app/dashboard/DashboardShell.js` | Menu par rôle, badges, logo stable |
| `app/dashboard/rh/` | RH & Agents |
| `app/dashboard/alarmes/` | Alarmes & IoT |
| `app/dashboard/abonnements/` | Abonnements |
| `app/dashboard/mon-espace/` | Espace agent |
| `app/dashboard/parametres/` | Paramètres |
| `app/dashboard/activite/` | Journal d'activité |
| `app/client/` | Portail client |
| `public/cosar-shield*.png` | Logo officiel site |
| `SUPABASE_ADMIN.sql` | Rattacher rôle admin |

## Upload GitHub (toi)

1. Dézippe **sans** créer un dossier intermédiaire bizarre  
2. Va sur : https://github.com/maxsow97-ship-it/Cosar-web/upload/main  
3. Glisse le contenu pour obtenir exactement :
   - `app/dashboard/rh/page.js`
   - `app/client/page.js`
   - `public/cosar-shield.png`
4. Message : `feat: COSAR ONE modules + design site + portail client`
5. **Commit changes**
6. Attends 1–2 min → https://cosar-web.vercel.app/login

## Après deploy — admin Supabase

1. Authentication → Users → Add user (ton email + mot de passe)
2. SQL Editor → coller `SUPABASE_ADMIN.sql` avec ton UUID
3. Connexion back-office

## Vérifs

- /dashboard/rh
- /dashboard/alarmes
- /client (compte role=client)
- Logo + typo alignés site
