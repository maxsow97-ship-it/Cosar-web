# Upload COSAR Enhanced sur GitHub

Repo : https://github.com/maxsow97-ship-it/Cosar-web

## Fichiers à ajouter / remplacer

```
app/login/page.js                          ← redirect selon rôle
app/dashboard/DashboardShell.js            ← menu rôles, badges, recherche
app/dashboard/shared/ui.js                 ← badges, empty, filtres, CSV/PDF
app/dashboard/shared/CreateForms.js
app/dashboard/rh/page.js + RHClient.js
app/dashboard/alarmes/page.js + AlarmesClient.js
app/dashboard/abonnements/page.js + AbonnementsClient.js
app/dashboard/mon-espace/page.js + MonEspaceClient.js
app/dashboard/parametres/page.js + ParametresClient.js
app/dashboard/activite/page.js + ActiviteClient.js
app/client/page.js + ClientPortalClient.js
```

## Étapes

1. GitHub → Cosar-web → Add file → Upload files
2. Déposer tout le contenu de `app/` en gardant les chemins
3. Commit sur `main`
4. Vercel redéploie automatiquement

## Inclus (1→10)

1. Badges alarmes / congés dans le shell  
2. Menu filtré par rôle  
3. Login → client `/client`, agent `/dashboard/mon-espace`  
4. StatusBadge FR  
5. EmptyState  
6. Filtres statut / site / période  
7. Export CSV + PDF (impression)  
8. Recherche globale header  
9. Page Paramètres  
10. Journal d’activité  

## 11–14

Voir ROADMAP_11_14.md (structure prête, besoin Storage / API).
